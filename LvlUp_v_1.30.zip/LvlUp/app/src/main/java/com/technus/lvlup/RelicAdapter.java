package com.technus.lvlup;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

public class RelicAdapter extends BaseAdapter {

    Context context;
    String[] relicNames;
    int [] relicIcons;

    public RelicAdapter(Context context, String[] relicNames, int[] relicIcons) {
        this.context = context;
        this.relicNames = relicNames;
        this.relicIcons = relicIcons;
    }

    @Override
    public int getCount() {
        return relicNames.length;
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {

        view = LayoutInflater.from(context).inflate(R.layout.resource_layout,viewGroup,false);
        ImageView imageView = view.findViewById(R.id.ResourceIcon);
        TextView textView = view.findViewById(R.id.tv_resource);

        imageView.setImageResource(relicIcons[i]);
        textView.setText(relicNames[i]);

        return view;
    }
}